package com.biblioconnect;

import java.util.ArrayList;
import java.util.List;

public class Patron {
    private int id;
    private String name;
    private String contactInfo;
    private List<Transaction> borrowingHistory;
    public Patron(int id, String name, String contactInfo) {
        this.id = id;
        this.name = name;
        this.contactInfo = contactInfo;
        this.borrowingHistory = new ArrayList<>();
    }

    public void addTransaction(Transaction transaction) {
        borrowingHistory.add(transaction);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }

    public List<Transaction> getBorrowingHistory() {
        return borrowingHistory;
    }

    public void displayPatronDetails() {
        System.out.println("Patron ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Contact Info: " + contactInfo);
        System.out.println("Borrowing History:");
        borrowingHistory.forEach(transaction -> 
            System.out.println("Borrowed: " + transaction.getBook().getTitle() + " on " + transaction.getBorrowDate())
        );
    }
}
