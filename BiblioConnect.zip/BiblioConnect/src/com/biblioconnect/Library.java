package com.biblioconnect;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Library {
    private List<Book> books;
    private List<Patron> patrons;
    private List<Transaction> transactions;
    private List<UserProfile> userProfiles; 

    public Library() {
        this.books = new ArrayList<>();
        this.patrons = new ArrayList<>();
        this.transactions = new ArrayList<>();
        this.userProfiles = new ArrayList<>();
    }
    public UserProfile findUserProfileById(int userId) {
        for (UserProfile userProfile : userProfiles) {
            if (userProfile.getPatron().getId() == userId) {
                return userProfile;
            }
        }
        return null;
    }
    public void addBook(Book book) {
        books.add(book);
        System.out.println("Book added: " + book.getTitle());
    }
    public void removeBook(String isbn) {
        books.removeIf(book -> book.getIsbn().equals(isbn));
        System.out.println("Book removed with ISBN: " + isbn);
    }
    public void registerPatron(Patron patron) {
        patrons.add(patron);
        System.out.println("Patron registered: " + patron.getName());
    }
    public void checkoutBook(String isbn, int patronId) {
        Optional<Book> book = books.stream()
                                   .filter(b -> b.getIsbn().equals(isbn) && b.isAvailable())
                                   .findFirst();
        Optional<Patron> patron = patrons.stream()
                                         .filter(p -> p.getId() == patronId)
                                         .findFirst();

        if (book.isPresent() && patron.isPresent()) {
            book.get().setAvailable(false);
            Transaction newTransaction = new Transaction(patron.get(), book.get(), new java.util.Date());
            transactions.add(newTransaction);
            System.out.println("Book checked out: " + book.get().getTitle());
        } else {
            System.out.println("Book checkout failed. Either book is not available or patron not found.");
        }
    }
    public void returnBook(String isbn) {
        Optional<Book> book = books.stream()
                                   .filter(b -> b.getIsbn().equals(isbn))
                                   .findFirst();

        if (book.isPresent() && !book.get().isAvailable()) {
            book.get().setAvailable(true);
            System.out.println("Book returned: " + book.get().getTitle());
        } else {
            System.out.println("Return failed. Book not found or already returned.");
        }
    }
    public void displayBooks() {
        System.out.println("Listing all books:");
        books.forEach(book -> book.displayDetails());
    }
    public void displayPatrons() {
        System.out.println("Listing all patrons:");
        patrons.forEach(patron -> System.out.println("ID: " + patron.getId() + ", Name: " + patron.getName()));
    }
}
