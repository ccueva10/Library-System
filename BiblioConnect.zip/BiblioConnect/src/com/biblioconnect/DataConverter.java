package com.biblioconnect;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DataConverter {

    public static List<Book> convertResultSetToBooks(ResultSet rs) throws SQLException {
        List<Book> books = new ArrayList<>();
        while (rs.next()) {
            Book book = new Book(
                    rs.getString("isbn"),
                    rs.getString("title"),
                    rs.getString("author"),
                    rs.getString("genre"),
                    rs.getBoolean("available"),
                    rs.getString("description")
            );
            books.add(book);
        }
        return books;
    }

    public static List<UserProfile> convertResultSetToUserProfiles(ResultSet rs) throws SQLException {
        List<UserProfile> userProfiles = new ArrayList<>();
        while (rs.next()) {
            UserProfile userProfile = new UserProfile(
                    new Patron(
                        rs.getInt("user_id"),
                        rs.getString("name"),
                        rs.getString("contactInfo")
                    ),
                    rs.getString("biography")
            );
            userProfiles.add(userProfile);
        }
        return userProfiles;
    }

    public static String serializeUserProfile(UserProfile userProfile) {
        return String.format(
                "{id: %d, name: '%s', biography: '%s'}",
                userProfile.getPatron().getId(),
                userProfile.getPatron().getName(),
                userProfile.getBiography()
        );
    }

    public static UserProfile deserializeUserProfile(String data) {
        int id = Integer.parseInt(data.substring(data.indexOf("id: ") + 4, data.indexOf(",")));
        String name = data.substring(data.indexOf("name: '") + 7, data.indexOf("',", data.indexOf("name: ")));
        String biography = data.substring(data.indexOf("biography: '") + 12, data.lastIndexOf("'"));
        return new UserProfile(new Patron(id, name, ""), biography);
    }
}
