package com.biblioconnect;

import java.util.Date;

import java.util.Scanner;

public class LibraryApp {
    private static Library library = new Library();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean exit = false;
        while (!exit) {
            System.out.println("\nWelcome to BiblioConnect!");
            System.out.println("1. Add Book");
            System.out.println("2. Remove Book");
            System.out.println("3. Register Patron");
            System.out.println("4. Check Out Book");
            System.out.println("5. Return Book");
            System.out.println("6. Post Message");
            System.out.println("7. Display All Books");
            System.out.println("8. Exit");

            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addBook();
                    break;
                case 2:
                    removeBook();
                    break;
                case 3:
                    registerPatron();
                    break;
                case 4:
                    checkOutBook();
                    break;
                case 5:
                    returnBook();
                    break;
                case 6:
                    postMessage();
                    break;
                case 7:
                    library.displayBooks();
                    break;
                case 8:
                    exit = true;
                    System.out.println("Exiting program.");
                    break;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
        scanner.close();
    }

    private static void addBook() {
        System.out.println("Enter ISBN:");
        String isbn = scanner.nextLine();
        System.out.println("Enter Title:");
        String title = scanner.nextLine();
        System.out.println("Enter Author:");
        String author = scanner.nextLine();
        System.out.println("Enter Genre:");
        String genre = scanner.nextLine();
        library.addBook(new Book(isbn, title, author, genre, true, ""));
    }

    private static void removeBook() {
        System.out.println("Enter ISBN of the book to remove:");
        String isbn = scanner.nextLine();
        library.removeBook(isbn);
    }

    private static void registerPatron() {
        System.out.println("Enter ID:");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter Name:");
        String name = scanner.nextLine();
        System.out.println("Enter Contact Info:");
        String contactInfo = scanner.nextLine();
        library.registerPatron(new Patron(id, name, contactInfo));
    }

    private static void checkOutBook() {
        System.out.println("Enter Patron ID:");
        int patronId = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter ISBN of the book to check out:");
        String isbn = scanner.nextLine();
        library.checkoutBook(isbn, patronId);
    }

    private static void returnBook() {
        System.out.println("Enter ISBN of the book to return:");
        String isbn = scanner.nextLine();
        library.returnBook(isbn);
    }

    private static void postMessage() {
        System.out.println("Enter your user ID:");
        int userId = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter your message:");
        String message = scanner.nextLine();
        UserProfile user = library.findUserProfileById(userId);
        if (user != null) {
            user.addPost(new Post(message, user, new Date()));
            System.out.println("Message posted.");
        } else {
            System.out.println("User not found.");
        }
    }
}
