package com.biblioconnect;

import java.util.ArrayList;
import java.util.List;

public class UserProfile {
    private Patron patron;
    private String biography;
    private List<Book> favoriteBooks;
    private List<Post> posts;
    public String getName() {
    	return patron.getName();
    }

    public UserProfile(Patron patron, String biography) {
        this.patron = patron;
        this.biography = biography;
        this.favoriteBooks = new ArrayList<>();
        this.posts = new ArrayList<>();
    }

    public void addFavoriteBook(Book book) {
        if (!favoriteBooks.contains(book)) {
            favoriteBooks.add(book);
        }
    }

    public void removeFavoriteBook(Book book) {
        favoriteBooks.remove(book);
    }

    public void addPost(Post post) {
        posts.add(post);
    }

    public Patron getPatron() {
        return patron;
    }

    public void setPatron(Patron patron) {
        this.patron = patron;
    }

    public String getBiography() {
        return biography;
    }

    public void setBiography(String biography) {
        this.biography = biography;
    }

    public List<Book> getFavoriteBooks() {
        return favoriteBooks;
    }

    public List<Post> getPosts() {
        return posts;
    }

    public void displayProfileDetails() {
        System.out.println("User Profile for: " + patron.getName());
        System.out.println("Biography: " + biography);
        System.out.println("Favorite Books:");
        favoriteBooks.forEach(book -> System.out.println(book.getTitle()));
        System.out.println("Posts:");
        posts.forEach(post -> System.out.println(post.getContent()));
    }
}
