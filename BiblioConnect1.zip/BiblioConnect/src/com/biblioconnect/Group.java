package com.biblioconnect;

import java.util.ArrayList;
import java.util.List;

public class Group {
    private String name;
    private String description;
    private List<UserProfile> members;
    private List<Discussion> discussions;

    public Group(String name, String description) {
        this.name = name;
        this.description = description;
        this.members = new ArrayList<>();
        this.discussions = new ArrayList<>();
    }

    public void addMember(UserProfile member) {
        if (!members.contains(member)) {
            members.add(member);
            System.out.println("New member added: " + member.getName());
        } else {
            System.out.println("Member already exists in the group.");
        }
    }

    public boolean removeMember(UserProfile member) {
        return members.remove(member);
    }

    public void addDiscussion(Discussion discussion) {
        discussions.add(discussion);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<UserProfile> getMembers() {
        return members;
    }

    public List<Discussion> getDiscussions() {
        return discussions;
    }

    public void displayGroupDetails() {
        System.out.println("Group Name: " + name);
        System.out.println("Description: " + description);
        System.out.println("Members Count: " + members.size());
        System.out.println("Discussions Count: " + discussions.size());
    }
}
