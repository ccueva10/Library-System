package com.biblioconnect;

import java.util.Date;

public class Comment {
    private String content;
    private UserProfile author;
    private Post post;
    private Date timestamp;

    public Comment(String content, UserProfile author, Post post, Date timestamp) {
        this.content = content;
        this.author = author;
        this.post = post;
        this.timestamp = timestamp;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public UserProfile getAuthor() {
        return author;
    }

    public void setAuthor(UserProfile author) {
        this.author = author;
    }

    public Post getPost() {
        return post;
    }

    public void setPost(Post post) {
        this.post = post;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public void displayCommentDetails() {
        System.out.println("Comment by: " + author.getName() + " at " + timestamp);
        System.out.println("Content: " + content);
    }
}
