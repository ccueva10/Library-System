package com.biblioconnect;

import java.util.ArrayList;
import java.util.List;

public class Discussion {
    private String topic;
    private Group group;
    private List<Post> posts;

    public Discussion(String topic, Group group) {
        this.topic = topic;
        this.group = group;
        this.posts = new ArrayList<>();
    }

    public void addPost(Post post) {
        posts.add(post);
    }

    public boolean removePost(Post post) {
        return posts.remove(post);
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public Group getGroup() {
        return group;
    }

    public void setGroup(Group group) {
        this.group = group;
    }

    public List<Post> getPosts() {
        return posts;
    }

    public void displayPosts() {
        System.out.println("Discussion Topic: " + topic);
        for (Post post : posts) {
            System.out.println("Post by " + post.getAuthor().getName() + ": " + post.getContent());
        }
    }
}
