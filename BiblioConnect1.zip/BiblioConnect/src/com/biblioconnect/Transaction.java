package com.biblioconnect;

import java.util.Date;

public class Transaction {
    private Patron patron;
    private Book book;
    private Date issueDate;
    private Date returnDate;
    private Date borrowDate;
    public Date getBorrowDate() {
    	return borrowDate;
    }

    public Transaction(Patron patron, Book book, Date issueDate) {
        this.patron = patron;
        this.book = book;
        this.issueDate = issueDate;
        this.returnDate = null;
    }

    public void markAsReturned(Date returnDate) {
        this.returnDate = returnDate;
        book.setAvailable(true);
    }

    public Patron getPatron() {
        return patron;
    }

    public Book getBook() {
        return book;
    }

    public Date getIssueDate() {
        return issueDate;
    }

    public Date getReturnDate() {
        return returnDate;
    }

    public void displayTransactionDetails() {
        System.out.println("Transaction Details:");
        System.out.println("Patron: " + patron.getName());
        System.out.println("Book: " + book.getTitle());
        System.out.println("Issue Date: " + issueDate);
        System.out.println("Return Date: " + (returnDate != null ? returnDate : "Not Returned Yet"));
    }
}
